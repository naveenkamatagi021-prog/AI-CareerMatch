import base64
import re

import streamlit as st

from utils.career_analyzer import (
    analyze_career_match,
    build_fallback_content,
    calculate_readiness,
)
from utils.career_chatbot import (
    OllamaConnectionError,
    evaluate_interview_answer,
    generate_career_content,
    generate_skill_gap_recommendation,
    prepare_career_content,
    prepare_skill_gap_recommendation,
    stream_career_question,
)
from utils.matcher import calculate_match
from utils.pdf_parser import extract_pdf_text
from utils.semantic_matcher import calculate_semantic_similarity
from utils.skill_extractor import extract_skills


st.set_page_config(page_title="AI CareerMatch", page_icon="CM", layout="wide")


def initialize_state():
    defaults = {
        "analysis": None,
        "chat_messages": [],
        "mock_active": False,
        "mock_complete": False,
        "mock_questions": [],
        "mock_index": 0,
        "mock_evaluations": [],
        "mock_last_evaluation": None,
        "skill_gap_ai": {},
        "skill_gap_errors": {},
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


initialize_state()

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');

    :root {
        --ink: #f6f7ff;
        --muted: #a9afd0;
        --navy: #080b21;
        --panel: #111633;
        --line: rgba(160, 151, 255, 0.18);
        --violet: #8b6cff;
        --blue: #4e8cff;
        --mint: #76e0c2;
        --rose: #ff9caf;
    }

    html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
    .stApp {
        background: radial-gradient(circle at 82% 4%, rgba(82, 67, 194, .24), transparent 28%),
                    radial-gradient(circle at 8% 38%, rgba(52, 102, 226, .12), transparent 24%),
                    var(--navy);
        color: var(--ink);
    }
    .block-container { max-width: 1240px; padding: 1.2rem 2rem 4rem; }
    h1, h2, h3, h4 { font-family: 'Space Grotesk', sans-serif; letter-spacing: -0.02em; }
    h1 { font-size: clamp(2.5rem, 5vw, 5.1rem) !important; line-height: 1.02 !important; }
    h2 { font-size: 2rem !important; }
    .brand { color: var(--ink); font-family: 'Space Grotesk', sans-serif; font-size: 1.25rem; font-weight: 700; padding: .6rem 0; }
    .brand-dot { color: var(--violet); }
    .eyebrow { color: #bcaeff; font-size: .75rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; }
    .hero { border: 1px solid var(--line); border-radius: 26px; margin: 2rem 0 1.4rem; overflow: hidden; padding: 3.2rem; position: relative; background: linear-gradient(125deg, #151940 0%, #242064 53%, #153f91 100%); }
    .hero:after { background: linear-gradient(135deg, rgba(255,255,255,.2), transparent 48%); border-radius: 50%; content: ''; height: 350px; position: absolute; right: -80px; top: -150px; width: 500px; }
    .hero-copy { max-width: 650px; position: relative; z-index: 1; }
    .hero-copy p { color: #d4d8f4; font-size: 1.05rem; line-height: 1.7; max-width: 560px; }
    .hero-art { background: rgba(8, 11, 33, .48); border: 1px solid rgba(255,255,255,.18); border-radius: 22px; box-shadow: 0 20px 60px rgba(0,0,0,.24); padding: 1.1rem; position: absolute; right: 5%; top: 22%; transform: rotate(3deg); width: 270px; z-index: 1; }
    .hero-art .score { color: var(--mint); font-family: 'Space Grotesk', sans-serif; font-size: 3.2rem; font-weight: 700; }
    .hero-art .mini-line { background: linear-gradient(90deg, var(--violet), var(--blue)); border-radius: 9px; height: 8px; margin: .55rem 0; }
    .hero-art .mini-line.short { width: 62%; }
    .section-kicker { color: var(--violet); font-size: .72rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; }
    .section-head { margin: 2.8rem 0 1.1rem; }
    .section-head p { color: var(--muted); margin-top: -.5rem; }
    .feature-card, .metric-card, .skill-card, .mock-hero { background: linear-gradient(145deg, rgba(25,31,70,.96), rgba(14,19,47,.96)); border: 1px solid var(--line); border-radius: 16px; box-shadow: 0 18px 45px rgba(0,0,0,.16); padding: 1.2rem; }
    .feature-card { min-height: 170px; }
    .feature-card .icon { color: #c4b7ff; font-size: 1.5rem; }
    .feature-card h3 { font-size: 1.1rem; margin: .5rem 0; }
    .feature-card p, .skill-card p { color: var(--muted); font-size: .9rem; line-height: 1.55; }
    .metric-card { min-height: 118px; }
    .metric-label { color: var(--muted); font-size: .75rem; text-transform: uppercase; }
    .metric-value { color: var(--ink); font-family: 'Space Grotesk', sans-serif; font-size: 1.8rem; font-weight: 700; margin: .3rem 0; }
    .metric-note { color: var(--mint); font-size: .75rem; }
    .pill { background: rgba(139,108,255,.16); border: 1px solid rgba(139,108,255,.35); border-radius: 999px; color: #d2c9ff; display: inline-block; font-size: .7rem; font-weight: 700; letter-spacing: .04em; padding: .25rem .55rem; text-transform: uppercase; }
    .pill.high { background: rgba(255,156,175,.12); border-color: rgba(255,156,175,.3); color: var(--rose); }
    .pill.mint { background: rgba(118,224,194,.12); border-color: rgba(118,224,194,.3); color: var(--mint); }
    .skill-title { align-items: center; display: flex; justify-content: space-between; }
    .skill-title h3 { margin: 0; }
    .score-ring { align-items: center; background: conic-gradient(var(--violet) var(--score), rgba(255,255,255,.1) 0); border-radius: 50%; display: flex; height: 142px; justify-content: center; margin: auto; width: 142px; }
    .score-ring-inner { align-items: center; background: var(--panel); border-radius: 50%; display: flex; flex-direction: column; height: 112px; justify-content: center; width: 112px; }
    .score-ring-inner strong { font-family: 'Space Grotesk', sans-serif; font-size: 2rem; }
    .score-ring-inner span { color: var(--muted); font-size: .7rem; }
    .mock-hero { background: linear-gradient(120deg, rgba(101,72,217,.22), rgba(40,132,220,.12)); }
    .mock-question { color: var(--ink); font-family: 'Space Grotesk', sans-serif; font-size: 1.35rem; line-height: 1.35; }
    .chat-wrap { background: rgba(17,22,51,.78); border: 1px solid var(--line); border-radius: 18px; padding: 1rem; }
    .pdf-preview { background: #0b0e24; border: 1px solid var(--line); border-radius: 14px; margin-top: 1rem; overflow: hidden; }
    .pdf-preview iframe { border: 0; display: block; height: 520px; width: 100%; }
    .pdf-open { color: #c5b9ff !important; display: inline-block; font-size: .85rem; margin: .7rem 0 1rem; text-decoration: none; }
    .pdf-open:hover { color: white !important; text-decoration: underline; }
    @media (max-width: 800px) { .block-container { padding: 1rem 1rem 3rem; } .hero { padding: 2rem 1.2rem; } .hero-art { display: none; } }
    </style>
    """,
    unsafe_allow_html=True,
)


def metric_card(label: str, value: str, note: str = ""):
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div>'
        f'<div class="metric-value">{value}</div><div class="metric-note">{note}</div></div>',
        unsafe_allow_html=True,
    )


def extract_resume_profile(resume_text: str, resume_skills: list[str]) -> dict:
    """Build a compact local profile without adding another Ollama request."""
    lines = [line.strip() for line in resume_text.splitlines() if line.strip()]
    candidate_name = "Not detected"
    for line in lines[:8]:
        if len(line.split()) <= 5 and not re.search(r"@|https?://|resume|curriculum", line, re.I):
            candidate_name = line
            break

    def section_text(*headings: str) -> str:
        heading_pattern = "|".join(re.escape(heading) for heading in headings)
        match = re.search(
            rf"(?:^|\n)\s*(?:{heading_pattern})\s*:?\s*\n?(.*?)(?=\n\s*[A-Z][A-Za-z /&-]{{2,30}}\s*:?\s*\n|$)",
            resume_text,
            re.I | re.S,
        )
        return " ".join(match.group(1).split())[:360] if match else "Not detected"

    role_education = section_text("summary", "profile", "objective", "education")
    projects = section_text("projects", "project experience")
    experience = section_text("experience", "work experience", "employment")
    education = section_text("education", "academic background")
    return {
        "candidate_name": candidate_name,
        "role_education": role_education,
        "skills": resume_skills or ["No supported skills detected"],
        "projects": projects,
        "experience": experience,
        "education": education,
    }


def render_pdf_preview(uploaded_resume, page_count: int, resume_text: str):
    """Render original uploaded bytes while keeping extracted text available internally."""
    pdf_bytes = uploaded_resume.getvalue()
    st.session_state.resume_pdf_bytes = pdf_bytes
    st.session_state.resume_pdf_name = uploaded_resume.name
    encoded_pdf = base64.b64encode(pdf_bytes).decode("ascii")
    file_size_mb = len(pdf_bytes) / (1024 * 1024)
    st.markdown(
        f'<span class="pill mint">{page_count} pages</span> '
        f'<span class="pill">{uploaded_resume.name}</span> '
        f'<span class="pill">{file_size_mb:.2f} MB</span>',
        unsafe_allow_html=True,
    )
    st.markdown(
        f'<div class="pdf-preview"><iframe src="data:application/pdf;base64,{encoded_pdf}" '
        'title="Uploaded resume PDF preview"></iframe></div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        f'<a class="pdf-open" href="data:application/pdf;base64,{encoded_pdf}" '
        'target="_blank" rel="noreferrer">Open Full PDF</a>',
        unsafe_allow_html=True,
    )
    profile = extract_resume_profile(resume_text, extract_skills(resume_text))
    st.markdown("### AI Extracted Resume Profile")
    profile_columns = st.columns(2, gap="small")
    profile_items = (
        ("Candidate name", profile["candidate_name"]),
        ("Role / education", profile["role_education"]),
        ("Projects", profile["projects"]),
        ("Experience", profile["experience"]),
        ("Education", profile["education"]),
    )
    for index, (label, value) in enumerate(profile_items):
        with profile_columns[index % 2]:
            st.markdown(f"**{label}**")
            st.caption(value)
    st.markdown("**Detected skills**")
    st.write(", ".join(profile["skills"]))
    with st.expander("View extracted text"):
        st.text(resume_text)


def run_analysis(resume_text: str, job_description: str, target_job_title: str):
    resume_skills = extract_skills(resume_text)
    job_skills = extract_skills(job_description)
    match_result = calculate_match(resume_skills, job_skills)
    semantic_score = None
    semantic_error = None
    try:
        semantic_score = calculate_semantic_similarity(resume_text, job_description)
    except Exception:
        semantic_error = "Semantic matching is unavailable. Keyword analysis remains available."
    overall_score = ((match_result["match_score"] + semantic_score) / 2 if semantic_score is not None else None)
    career_analysis = analyze_career_match(
        resume_skills=resume_skills,
        required_skills=job_skills,
        matching_skills=match_result["matching_skills"],
        missing_skills=match_result["missing_skills"],
        keyword_match_score=match_result["match_score"],
        semantic_similarity_score=semantic_score,
        overall_match_score=overall_score,
    )
    analysis = {
        "resume_text": resume_text,
        "job_description": job_description,
        "target_job_title": target_job_title or "Target role",
        "resume_skills": resume_skills,
        "job_skills": job_skills,
        **match_result,
        "semantic_score": semantic_score,
        "overall_score": overall_score,
        "semantic_error": semantic_error,
        "career_analysis": career_analysis,
    }
    try:
        if job_skills:
            generated = generate_career_content(analysis)
            content = prepare_career_content(generated, analysis)
            fallback = build_fallback_content(analysis)
            content["interview_questions"] = {**fallback["interview_questions"], **content["interview_questions"]}
            content["learning_roadmap"] = fallback["learning_roadmap"]
            content_error = None
        else:
            content = build_fallback_content(analysis)
            content_error = "No recognized job skills were detected."
    except OllamaConnectionError:
        content = build_fallback_content(analysis)
        content_error = "Ollama content was unavailable; deterministic guidance is shown."
    analysis["career_content"] = content
    analysis["career_content_error"] = content_error
    analysis["readiness"] = calculate_readiness(analysis)
    return analysis


def generate_ai_skill_roadmaps(analysis: dict):
    """Generate only uncached missing-skill roadmaps after explicit user action."""
    results = dict(st.session_state.skill_gap_ai)
    errors = dict(st.session_state.skill_gap_errors)
    for skill in analysis["missing_skills"]:
        if skill in results:
            continue
        try:
            raw = generate_skill_gap_recommendation(
                analysis.get("target_job_title", "Target role"),
                analysis["job_description"],
                tuple(analysis["resume_skills"]),
                skill,
                tuple(analysis["matching_skills"]),
                analysis["overall_score"],
            )
            results[skill] = prepare_skill_gap_recommendation(raw, skill)
            errors.pop(skill, None)
        except OllamaConnectionError as error:
            errors[skill] = str(error)
    st.session_state.skill_gap_ai = results
    st.session_state.skill_gap_errors = errors


def render_nav():
    left, nav, action = st.columns([2, 7, 1.4])
    with left:
        st.markdown('<div class="brand">AI Career<span class="brand-dot">Match</span></div>', unsafe_allow_html=True)
    with nav:
        st.caption("Home   Resume Analyzer   Job Match   Skill Gap   Mock Interview   AI Assistant")
    with action:
        st.button("Get Started", key="nav_get_started", use_container_width=True)


def render_hero():
    st.markdown('<div class="hero"><div class="hero-copy"><div class="eyebrow">AI-powered career intelligence</div>', unsafe_allow_html=True)
    st.markdown("# Find the right job.<br>Build the right skills.<br>Get interview ready.", unsafe_allow_html=True)
    st.markdown("AI CareerMatch analyzes your resume, compares it with job requirements, identifies skill gaps and helps you prepare for your target role.", unsafe_allow_html=True)
    st.button("Analyze My Resume", type="primary", key="hero_analyze")
    st.markdown('</div><div class="hero-art"><div class="eyebrow">Career readiness</div><div class="score">78%</div><div class="mini-line"></div><div class="mini-line short"></div><p>Resume intelligence<br>Semantic fit<br>Interview confidence</p></div></div>', unsafe_allow_html=True)


def render_features():
    st.markdown('<div class="section-head"><div class="section-kicker">One workspace, every advantage</div><h2>Everything you need to become job ready.</h2></div>', unsafe_allow_html=True)
    cards = [
        ("01", "Resume Intelligence", "Upload your resume and automatically extract the skills that matter for your target role."),
        ("02", "AI Job Matching", "Compare keyword coverage with semantic fit and see exactly where your profile stands."),
        ("03", "AI Interview Coach", "Practice role-specific questions generated from your resume and target job context."),
    ]
    columns = st.columns(3, gap="medium")
    for column, (number, title, text) in zip(columns, cards):
        with column:
            st.markdown(f'<div class="feature-card"><div class="icon">{number}</div><h3>{title}</h3><p>{text}</p></div>', unsafe_allow_html=True)


def render_dashboard(analysis: dict):
    st.markdown('<div class="section-head"><div class="section-kicker">Your career signal</div><h2>Career readiness dashboard</h2><p>A clear view of your fit, strengths and next moves.</p></div>', unsafe_allow_html=True)
    readiness = analysis["readiness"]
    cols = st.columns(6, gap="small")
    items = [
        ("Job Match Score", f"{analysis['match_score']:.0f}%", "Keyword coverage"),
        ("Semantic Similarity", f"{analysis['semantic_score']:.0f}%" if analysis["semantic_score"] is not None else "N/A", "Meaning and context"),
        ("Skills Matched", str(analysis["matching_skill_count"]), "Detected strengths"),
        ("Missing Skills", str(analysis["missing_skill_count"]), "Learning opportunities"),
        ("Interview Readiness", f"{readiness['interview_readiness']}%", "Skill coverage"),
        ("Career Readiness", f"{readiness['career_readiness']}%", "Combined signal"),
    ]
    for column, item in zip(cols, items):
        with column:
            metric_card(*item)
    st.progress(readiness["career_readiness"])


def render_workspace():
    st.markdown('<div class="section-head"><div class="section-kicker">Start with your context</div><h2>Build your career match</h2><p>Upload a readable PDF and paste the complete target job description.</p></div>', unsafe_allow_html=True)
    resume_column, job_column = st.columns(2, gap="large")
    resume_text = ""
    with resume_column:
        st.markdown('<div class="skill-card"><h3>Resume Analyzer</h3><p>Your PDF stays local to this workspace.</p>', unsafe_allow_html=True)
        uploaded_resume = st.file_uploader("Upload resume PDF", type=["pdf"], label_visibility="collapsed")
        if uploaded_resume is not None:
            try:
                page_count, resume_text = extract_pdf_text(uploaded_resume)
            except ValueError as error:
                st.error(str(error))
            else:
                render_pdf_preview(uploaded_resume, page_count, resume_text)
        st.markdown("</div>", unsafe_allow_html=True)
    with job_column:
        st.markdown('<div class="skill-card"><h3>Target Job</h3><p>Paste the role you want to move toward.</p>', unsafe_allow_html=True)
        target_job_title = st.text_input("Target job title", placeholder="e.g. Data Analyst", key="target_job_title")
        job_description = st.text_area("Job description", height=180, placeholder="Paste the complete job description here...", label_visibility="collapsed", key="job_description")
        analyze = st.button("Analyze My Resume + Job", type="primary", use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)
    if analyze:
        if not resume_text:
            st.session_state.analysis = None
            st.session_state.chat_messages = []
            st.error("Upload a readable resume PDF to begin.")
        elif not job_description.strip():
            st.session_state.analysis = None
            st.session_state.chat_messages = []
            st.error("Paste a job description to calculate your match.")
        else:
            with st.spinner("Analyzing your career fit..."):
                st.session_state.analysis = run_analysis(resume_text, job_description, target_job_title)
            st.session_state.chat_messages = []
            st.session_state.skill_gap_ai = {}
            st.session_state.skill_gap_errors = {}
            st.session_state.mock_active = False
            st.session_state.mock_complete = False
            st.rerun()


def render_skill_sections(analysis: dict):
    st.markdown('<div class="section-head"><div class="section-kicker">Signal breakdown</div><h2>Strengths and skill gaps</h2></div>', unsafe_allow_html=True)
    strength_col, gap_col = st.columns(2, gap="large")
    with strength_col:
        st.markdown('<div class="skill-card"><div class="skill-title"><h3>Strongest skills</h3><span class="pill mint">Detected in resume</span></div>', unsafe_allow_html=True)
        if analysis["matching_skills"]:
            for skill in analysis["matching_skills"]:
                st.markdown(f'<p><strong>{skill}</strong> <span class="pill mint">Job relevant</span></p>', unsafe_allow_html=True)
        else:
            st.info("No matching skills detected yet.")
        st.markdown("</div>", unsafe_allow_html=True)
    with gap_col:
        st.markdown('<div class="skill-card"><div class="skill-title"><h3>Skill gap roadmap</h3><span class="pill high">Prioritized</span></div>', unsafe_allow_html=True)
        if analysis["missing_skills"] and st.button("Generate AI Roadmap", type="primary", use_container_width=True):
            with st.spinner("Generating personalized skill roadmaps..."):
                generate_ai_skill_roadmaps(analysis)
            st.rerun()
        ai_roadmaps = st.session_state.skill_gap_ai
        fallback_roadmaps = analysis["career_content"]["learning_roadmap"]
        roadmap = {**fallback_roadmaps, **ai_roadmaps}
        if roadmap:
            for position, (skill, details) in enumerate(roadmap.items()):
                priority = details.get("priority", "High" if position < 2 else "Medium" if position < 4 else "Low")
                with st.expander(f"{skill}  ·  {priority} priority"):
                    st.markdown(f'<span class="pill high">Missing skill</span> <span class="pill">{priority}</span>', unsafe_allow_html=True)
                    st.write(f"**Why it matters:** {details['why_it_matters']}")
                    if "current_level" in details:
                        st.write(f"**Current level:** {details['current_level']}  →  **Target level:** {details['target_level']}")
                        if details.get("learning_topics"):
                            st.write("**Learning topics:** " + ", ".join(details["learning_topics"]))
                        path = st.columns(3, gap="small")
                        for column, level in zip(path, ("Beginner", "Intermediate", "Advanced")):
                            with column:
                                st.markdown(f"**{level}**")
                                st.caption(details["learning_path"][level.casefold()])
                    else:
                        path = st.columns(3, gap="small")
                        for column, level in zip(path, ("Beginner", "Intermediate", "Advanced")):
                            with column:
                                st.markdown(f"**{level}**")
                                st.caption(details[level.casefold()])
                    st.write("**Practice tasks**")
                    for task in details["practice_tasks"]:
                        st.write(f"- {task}")
                    project = details.get("project", details.get("project_idea", ""))
                    st.caption(f"Estimated duration: {details['duration']}  ·  Project: {project}")
                    if details.get("job_readiness_impact"):
                        st.write(f"**Job readiness impact:** {details['job_readiness_impact']}")
                if skill in st.session_state.skill_gap_errors:
                    st.warning(f"AI roadmap unavailable for {skill}; showing the deterministic fallback.")
        else:
            st.success("No skill gaps detected for the recognized job requirements.")
        st.markdown("</div>", unsafe_allow_html=True)


def start_mock_interview(analysis: dict):
    questions = []
    for skill, skill_questions in analysis["career_content"]["interview_questions"].items():
        for question in skill_questions:
            questions.append({"skill": skill, "question": question})
    st.session_state.mock_questions = questions
    st.session_state.mock_index = 0
    st.session_state.mock_evaluations = []
    st.session_state.mock_last_evaluation = None
    st.session_state.mock_active = bool(questions)
    st.session_state.mock_complete = False


def render_mock_interview(analysis: dict):
    st.markdown('<div class="section-head"><div class="section-kicker">Practice under pressure</div><h2>AI mock interview</h2><p>One question at a time, with focused feedback from llama3.2.</p></div>', unsafe_allow_html=True)
    st.markdown('<div class="mock-hero"><div class="eyebrow">AI mock interview</div><h3>Practice a realistic interview tailored to your target job.</h3><p>Answer naturally. Ollama evaluates technical depth, relevance and communication after each response.</p></div>', unsafe_allow_html=True)
    if not st.session_state.mock_active and not st.session_state.mock_complete:
        settings = st.columns(3, gap="medium")
        with settings[0]: st.selectbox("Target role", ["Target job description"], key="mock_role")
        with settings[1]: st.selectbox("Difficulty", ["Intermediate", "Advanced"], key="mock_difficulty")
        with settings[2]: st.selectbox("Questions", ["5 questions", "3 questions"], key="mock_question_count")
        if st.button("Start Interview", type="primary", use_container_width=True):
            start_mock_interview(analysis)
            st.rerun()
        return
    if st.session_state.mock_complete:
        st.success("Interview complete. Review your feedback and use the assistant for another practice round.")
        if st.button("Start another interview"):
            start_mock_interview(analysis)
            st.rerun()
        return
    index = st.session_state.mock_index
    question_data = st.session_state.mock_questions[index]
    st.markdown(f'<span class="pill">Question {index + 1} of {len(st.session_state.mock_questions)}</span> <span class="pill mint">{question_data["skill"]}</span>', unsafe_allow_html=True)
    st.progress(index / len(st.session_state.mock_questions))
    st.markdown(f'<div class="mock-question">{question_data["question"]}</div>', unsafe_allow_html=True)
    answer = st.text_area("Your answer", height=150, key=f"mock_answer_{index}", placeholder="Structure your answer with context, action and result...")
    if st.button("Submit answer", type="primary"):
        if not answer.strip():
            st.warning("Write an answer before submitting it for feedback.")
        else:
            with st.spinner("Evaluating answer..."):
                try:
                    evaluation = evaluate_interview_answer(analysis, question_data["question"], answer)
                except OllamaConnectionError:
                    evaluation = {"technical_score": 0, "relevance_score": 0, "communication_score": 0, "overall_score": 0, "feedback": "Ollama is unavailable, so this answer could not be evaluated.", "improvement": "Start Ollama and try the answer again."}
            st.session_state.mock_evaluations.append(evaluation)
            st.session_state.mock_last_evaluation = evaluation
            if index + 1 >= len(st.session_state.mock_questions):
                st.session_state.mock_active = False
                st.session_state.mock_complete = True
            else:
                st.session_state.mock_index += 1
            st.rerun()
    if st.session_state.mock_last_evaluation:
        evaluation = st.session_state.mock_last_evaluation
        score_cols = st.columns(4)
        score_items = [("Technical", "technical_score"), ("Relevance", "relevance_score"), ("Communication", "communication_score"), ("Overall", "overall_score")]
        for column, (label, key) in zip(score_cols, score_items):
            with column:
                metric_card(label, f"{evaluation[key]}%")
        st.info(f"{evaluation['feedback']} Improvement: {evaluation['improvement']}")


def render_assistant(analysis: dict | None):
    st.markdown('<div class="section-head"><div class="section-kicker">Your local AI career copilot</div><h2>AI Career Assistant</h2><p>Ask grounded questions about your resume, target role and next move.</p></div>', unsafe_allow_html=True)
    st.markdown('<div class="chat-wrap">Try: “Why is my match score low?” · “What should I learn first?” · “How can I improve my resume?”</div>', unsafe_allow_html=True)
    for message in st.session_state.chat_messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    question = st.chat_input("Ask your career question...")
    if question:
        history = st.session_state.chat_messages
        st.session_state.chat_messages.append({"role": "user", "content": question})
        if analysis is None:
            answer = "Upload a resume, paste a job description and analyze them before asking a candidate-specific question."
            st.session_state.chat_messages.append({"role": "assistant", "content": answer})
        else:
            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    placeholder = st.empty()
                    parts = []
                    try:
                        for chunk in stream_career_question(question, analysis, history):
                            parts.append(chunk)
                            placeholder.markdown("".join(parts) + "▌")
                        answer = "".join(parts).strip()
                        placeholder.markdown(answer)
                    except OllamaConnectionError as error:
                        answer = f"The local AI assistant is unavailable: {error}"
                        placeholder.error(answer)
            st.session_state.chat_messages.append({"role": "assistant", "content": answer})
        st.session_state.chat_messages = st.session_state.chat_messages[-6:]
        st.rerun()


render_nav()
render_hero()
render_features()
render_workspace()
analysis = st.session_state.analysis
if analysis:
    render_dashboard(analysis)
    st.markdown('<div class="section-head"><div class="section-kicker">Detailed intelligence</div><h2>Match analysis</h2></div>', unsafe_allow_html=True)
    score_cols = st.columns(3, gap="medium")
    score_data = [
        (analysis["match_score"], "keyword fit"),
        (analysis["semantic_score"] or 0, "semantic fit"),
        (analysis["overall_score"] or analysis["match_score"], "overall fit"),
    ]
    for column, (score, label) in zip(score_cols, score_data):
        with column:
            st.markdown(f'<div class="score-ring" style="--score: {score}%"><div class="score-ring-inner"><strong>{score:.0f}%</strong><span>{label}</span></div></div>', unsafe_allow_html=True)
    st.caption("Semantic similarity compares the meaning of the resume and role. Keyword fit reflects detected skill coverage.")
    render_skill_sections(analysis)
    render_mock_interview(analysis)
    with st.expander("Full extracted text and score explanation"):
        st.write(analysis["career_analysis"]["match_explanation"])
        st.text(analysis["resume_text"])
render_assistant(analysis)
