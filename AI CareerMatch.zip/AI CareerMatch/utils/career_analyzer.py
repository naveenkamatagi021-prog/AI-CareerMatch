from collections.abc import Iterable


def _unique_skills(skills: Iterable[str]) -> list[str]:
    unique_skills = []
    seen = set()
    for skill in skills:
        normalized_skill = skill.casefold()
        if normalized_skill not in seen:
            seen.add(normalized_skill)
            unique_skills.append(skill)
    return unique_skills


def analyze_career_match(
    resume_skills: Iterable[str],
    required_skills: Iterable[str],
    matching_skills: Iterable[str],
    missing_skills: Iterable[str],
    keyword_match_score: float,
    semantic_similarity_score: float | None,
    overall_match_score: float | None,
) -> dict:
    """Build a deterministic career analysis from detected skills and scores."""
    resume_skills = _unique_skills(resume_skills)
    required_skills = _unique_skills(required_skills)
    matching_skills = _unique_skills(matching_skills)
    missing_skills = _unique_skills(missing_skills)

    if not required_skills:
        match_explanation = (
            "No recognized job skills were detected, so the keyword score is 0%. "
            "Add a job description with supported skills for a more useful analysis."
        )
    elif overall_match_score is None:
        match_explanation = (
            f"The candidate matches {len(matching_skills)} of {len(required_skills)} "
            f"detected job skills, producing a {keyword_match_score:.0f}% keyword score. "
            "The overall score is unavailable because semantic similarity could not be calculated."
        )
    else:
        match_explanation = (
            f"The candidate matches {len(matching_skills)} of {len(required_skills)} "
            f"detected job skills. The {keyword_match_score:.0f}% keyword score and "
            f"{semantic_similarity_score:.0f}% semantic similarity produce an overall "
            f"AI match score of {overall_match_score:.0f}%."
        )

    candidate_strengths = matching_skills
    skill_gaps = missing_skills
    priority_learning_plan = [
        {"rank": rank, "skill": skill}
        for rank, skill in enumerate(skill_gaps, start=1)
    ]

    improvement_suggestions = []
    if skill_gaps:
        improvement_suggestions.append(
            "Build or document practical work that demonstrates the missing job skills."
        )
        improvement_suggestions.append(
            "Update resume bullets with measurable outcomes for the matching skills."
        )
    elif required_skills:
        improvement_suggestions.append(
            "Strengthen the resume with measurable outcomes tied to the detected job skills."
        )
    else:
        improvement_suggestions.append(
            "Add a complete job description with recognizable technical skills before improving the match."
        )

    return {
        "match_explanation": match_explanation,
        "candidate_strengths": candidate_strengths,
        "skill_gaps": skill_gaps,
        "priority_learning_plan": priority_learning_plan,
        "improvement_suggestions": improvement_suggestions,
    }


def build_fallback_content(context: dict) -> dict:
    """Provide useful deterministic content when the local model is unavailable."""
    required_skills = list(context.get("job_skills", []))
    missing_skills = list(context.get("missing_skills", []))
    matching_lookup = {skill.casefold() for skill in context.get("matching_skills", [])}
    interview_questions = {}
    for skill in required_skills:
        interview_questions[skill] = [
            f"What technical decisions would you make when using {skill} for this role?",
            f"How would you troubleshoot a real-world problem involving {skill}?",
            f"Describe a project or work example where you applied {skill}.",
        ]

    learning_roadmap = {}
    for position, skill in enumerate(missing_skills):
        priority = "High" if position < 2 else "Medium" if position < 4 else "Low"
        learning_roadmap[skill] = {
            "why_it_matters": f"{skill} is listed as a required skill and is not detected in the resume.",
            "beginner": f"Learn the core concepts and terminology of {skill}.",
            "intermediate": f"Build a guided implementation using {skill} and document the key decisions.",
            "advanced": f"Apply {skill} in a production-style workflow with testing and monitoring.",
            "practice_tasks": [
                f"Complete a focused {skill} tutorial and reproduce its main example.",
                f"Add a small {skill} feature to a personal project.",
            ],
            "duration": "2-4 weeks",
            "project_idea": f"Create a small portfolio project that demonstrates {skill} in the target job context.",
            "priority": priority,
        }

    return {"interview_questions": interview_questions, "learning_roadmap": learning_roadmap}


def calculate_readiness(context: dict) -> dict:
    required_count = context.get("required_skill_count", 0)
    matching_count = context.get("matching_skill_count", 0)
    keyword_score = context.get("match_score", 0.0)
    semantic_score = context.get("semantic_score")
    overall_score = context.get("overall_score")
    skill_coverage = matching_count / required_count * 100 if required_count else 0.0
    interview_readiness = round(skill_coverage)
    readiness_inputs = [keyword_score, interview_readiness]
    if semantic_score is not None:
        readiness_inputs.append(semantic_score)
    career_readiness = round(sum(readiness_inputs) / len(readiness_inputs))
    return {
        "interview_readiness": interview_readiness,
        "career_readiness": career_readiness,
        "overall_display_score": overall_score if overall_score is not None else keyword_score,
    }