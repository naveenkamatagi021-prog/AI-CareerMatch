from pypdf import PdfReader


def extract_pdf_text(pdf_file) -> tuple[int, str]:
    """Return the page count and combined text from an uploaded PDF."""
    try:
        reader = PdfReader(pdf_file)
    except Exception as error:
        raise ValueError("The PDF could not be read. Please upload a valid PDF file.") from error

    page_text = []
    try:
        for page in reader.pages:
            page_text.append(page.extract_text() or "")
    except Exception as error:
        raise ValueError("The PDF could not be read or its text could not be extracted.") from error

    extracted_text = "\n\n".join(text.strip() for text in page_text).strip()
    if not extracted_text:
        raise ValueError("No extractable text was found in this PDF.")

    return len(reader.pages), extracted_text