import streamlit as st

try:
    from sentence_transformers import SentenceTransformer, util
except ImportError:
    SentenceTransformer = None
    util = None


MODEL_NAME = "all-MiniLM-L6-v2"


@st.cache_resource(show_spinner="Loading semantic matching model...")
def load_embedding_model():
    """Load the local embedding model once per Streamlit process."""
    if SentenceTransformer is None:
        raise RuntimeError("sentence-transformers is not installed.")
    return SentenceTransformer(MODEL_NAME)


def calculate_semantic_similarity(resume_text: str, job_description: str) -> float:
    """Return cosine similarity as a percentage between two text inputs."""
    if not resume_text.strip() or not job_description.strip():
        return 0.0

    model = load_embedding_model()
    embeddings = model.encode(
        [resume_text, job_description],
        convert_to_tensor=True,
        normalize_embeddings=True,
    )
    cosine_similarity = float(util.cos_sim(embeddings[0], embeddings[1]).item())
    return max(0.0, min(100.0, cosine_similarity * 100))