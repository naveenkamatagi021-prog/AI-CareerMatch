import re


SKILL_DICTIONARY = (
    "Python",
    "SQL",
    "Java",
    "JavaScript",
    "HTML",
    "CSS",
    "React",
    "Next.js",
    "Node.js",
    "FastAPI",
    "Flask",
    "Django",
    "MongoDB",
    "PostgreSQL",
    "MySQL",
    "Power BI",
    "Tableau",
    "Excel",
    "Pandas",
    "NumPy",
    "Scikit-learn",
    "TensorFlow",
    "PyTorch",
    "Machine Learning",
    "Deep Learning",
    "NLP",
    "RAG",
    "LangChain",
    "Docker",
    "AWS",
    "Git",
    "GitHub",
    "REST API",
    "Linux",
)


def extract_skills(text: str) -> list[str]:
    """Return dictionary skills found in text, preserving dictionary order."""
    if not text:
        return []

    found_skills = []
    for skill in SKILL_DICTIONARY:
        pattern = rf"(?<!\w){re.escape(skill)}(?!\w)"
        if re.search(pattern, text, flags=re.IGNORECASE):
            found_skills.append(skill)

    return found_skills