from collections.abc import Iterable


def _unique_skills(skills: Iterable[str]) -> list[str]:
    unique_skills = []
    seen = set()
    for skill in skills:
        normalized_skill = skill.casefold()
        if normalized_skill not in seen:
            seen.add(normalized_skill)
            unique_skills.append(skill)
    return unique_skills


def calculate_match(resume_skills: Iterable[str], required_skills: Iterable[str]) -> dict:
    """Return deduplicated skill matches, counts, and a zero-safe match score."""
    resume_skills = _unique_skills(resume_skills)
    required_skills = _unique_skills(required_skills)
    resume_skill_lookup = {skill.casefold() for skill in resume_skills}

    matching_skills = [
        skill for skill in required_skills if skill.casefold() in resume_skill_lookup
    ]
    missing_skills = [
        skill for skill in required_skills if skill.casefold() not in resume_skill_lookup
    ]
    required_skill_count = len(required_skills)
    matching_skill_count = len(matching_skills)
    match_score = (
        matching_skill_count / required_skill_count * 100
        if required_skill_count
        else 0.0
    )

    return {
        "matching_skills": matching_skills,
        "missing_skills": missing_skills,
        "strongest_matching_skills": matching_skills,
        "matching_skill_count": matching_skill_count,
        "required_skill_count": required_skill_count,
        "missing_skill_count": len(missing_skills),
        "match_score": match_score,
    }